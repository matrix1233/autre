sudo docker login -u matrix1233 -p 123456123456
sudo docker build -t matrix1233/pfr:web --file Dockerfile1 .
sudo docker build -t matrix1233/pfr:app --file Dockerfile2 .
sudo docker build -t matrix1233/pfr:bdd --file Dockerfile3 .
sudo docker push matrix1233/pfr:bdd
sudo docker push matrix1233/pfr:app
sudo docker push matrix1233/pfr:web
sudo docker-compose up -d
