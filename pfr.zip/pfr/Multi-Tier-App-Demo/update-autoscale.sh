#!/bin/bash
sudo cp html/* /var/www/html/appdemo/
sudo cp scripts/* /var/www/html/appdemo/


